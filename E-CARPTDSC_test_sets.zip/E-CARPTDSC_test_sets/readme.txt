Some variables are described as follows:

STARTTIME and ENDTIME:  the lower and upper bounds of the planning horizon, respectively.
INTERVALS:  the number of time intervals.
STATIONS:  locations of the recharging stations, i.e., the vertices that also serve as charging stations.
STATIONS_TIMES:  the maximum number of times each recharging station can be used for recharging.
time_values in LIST_EDG_REQ:  the time intervals and the corresponding values of $P^{l}{ij}$ within these intervals. The format is
[
P^{l}{ij} [begin_time,end_time].
]
Each task has 10 such time intervals.